# Fake News Detector --- Group 2

This C++ program uses various methods to estimate the veracity of an online news article.

It's being written as a Group Project assignment at the University of Lincoln.

CMP2089M-1718 - Group Project (Fake News Detector)

|             |                   |                          |
|:------------|:------------------|:-------------------------|
| COE16609509 | James Coe         | Napk1ns / FakeNewsGroup2 |
| VAI16606590 | Paulius Vaitaitis | MrBlaster                |
| MIL16606229 | Lee Milner        | Lmilner                  |
| ANS15595025 | Ethan Ansell      | zemja                    |
| WAN16641828 | Jiahe Wang        | Hearn000                 |
| ZHU15625064 | Dahai Zhu         | -                        |
| WOR16609305 | Ashley Worth      | AshWorth24               |