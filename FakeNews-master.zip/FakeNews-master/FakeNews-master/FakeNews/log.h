#pragma once

#include "Logger.h"

namespace fakenews
{

namespace log
{

extern Logger log;
extern Logger error;
extern Logger warning;
extern Logger success;

}

}